// userChrome.js - запускает наши скрипты на всех страницах

(function() {
    // Загружаем spoof-скрипт
    Services.scriptloader.loadSubScript(
        "chrome://userChrome/content/spoof-windows.js",
        null, "UTF-8"
    );
})();
