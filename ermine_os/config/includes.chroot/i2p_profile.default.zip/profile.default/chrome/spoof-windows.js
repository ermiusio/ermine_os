// ==UserScript==
// @name         Windows + Chrome Spoof for Tor Browser
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    const winUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36";

    const props = {
        userAgent: winUA,
        platform: "Win32",
        oscpu: "Windows NT 10.0; Win64; x64",
        appVersion: "5.0 (Windows)",
        appName: "Netscape",
        appCodeName: "Mozilla",
        product: "Gecko",
        productSub: "20100101",
        vendor: "Google Inc.",
        vendorSub: "",
        hardwareConcurrency: 8,
        deviceMemory: 8,
        language: "en-US",
        languages: ["en-US", "en"]
    };

    // Переопределяем свойства navigator
    for (let [key, value] of Object.entries(props)) {
        try {
            Object.defineProperty(navigator, key, {
                get: () => value,
                configurable: false,
                enumerable: true
            });
        } catch (e) {}
    }

    // Дополнительно переопределяем через toString, чтобы некоторые проверки не ломались
    const originalToString = Function.prototype.toString;
    Function.prototype.toString = function() {
        if (this === navigator.userAgent) return winUA;
        return originalToString.apply(this, arguments);
    };

    console.log('%c[Windows Spoof] Navigator успешно переопределён под Windows 10 + Chrome', 'color: #0f0; font-weight: bold');
})();
